def classify(n):
    if n > 0:
        return "pos"
    if n < 0:
        return "neg"
    return "zero"


def safe_div(a, b):
    if b == 0:
        return None
    return a / b


def slugify(text):
    cleaned = text.strip().lower()
    return cleaned.replace(" ", "-")


def clamp(value, low, high):
    if value < low:
        return low
    if value > high:
        return high
    return value
